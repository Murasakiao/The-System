# ==================== run.py (Root directory) ====================
import os
from app import create_app
from app.utils import init_db

app = create_app()

# Initialize database on first run
init_db(app)

if __name__ == '__main__':
    port = int(os.environ.get('PORT', 5000))
    app.run(host='0.0.0.0', port=port, debug=True)