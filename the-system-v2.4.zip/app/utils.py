# ==================== app/utils.py ====================
from datetime import datetime, date, timedelta
import random
import json
from werkzeug.security import generate_password_hash

from app import db
from app.models import User, Quest, DailyQuestTemplate, DailyQuestAssignment
from app.quest_system import DAILY_QUEST_TEMPLATES, generate_daily_quests_for_user

def get_daily_training_category(user_id):
    """Determine the training category for the day"""
    last_assignment = DailyQuestAssignment.query.filter_by(
        user_id=user_id
    ).order_by(DailyQuestAssignment.assigned_date.desc()).first()
    
    categories = list(DAILY_QUEST_TEMPLATES.keys())
    
    if not last_assignment:
        return random.choice(categories)
    
    categories.remove(last_assignment.category)
    return random.choice(categories)

def generate_daily_quests(user_id):
    """Generate daily quests for a user using the adaptive system - ONE category per day"""
    today = date.today()
    user = User.query.get(user_id)
    
    if user.last_daily_quest_date == today:
        return
    
    # Determine today's category (rotating, not repeating yesterday's)
    selected_category = get_daily_training_category(user_id)
    
    # Use adaptive quest generation for the selected category only
    adaptive_quests, category = generate_daily_quests_for_user(user, selected_category)
    
    # Create ONE daily quest assignment for the selected category
    existing_assignment = DailyQuestAssignment.query.filter_by(
        user_id=user_id,
        assigned_date=today
    ).first()
    
    if not existing_assignment:
        assignment = DailyQuestAssignment(
            user_id=user_id,
            assigned_date=today,
            category=category,
            completed=False
        )
        db.session.add(assignment)
    
    # Create quests for all templates in the selected category
    for quest_data in adaptive_quests:
        quest = Quest(
            name=quest_data['name'],
            description=f"Complete {quest_data['target']} {quest_data['unit']} of {quest_data['name']}. Difficulty: {quest_data['difficulty']}",
            target=quest_data['target'],
            unit=quest_data['unit'],
            duration=quest_data['duration'],
            difficulty=quest_data['difficulty'],
            reward=quest_data['reward'],
            user_id=user_id,
            tags=json.dumps([quest_data['category'], 'daily']),
            due_date=datetime.combine(today, datetime.max.time()),
            priority=3
        )
        db.session.add(quest)
    
    user.last_daily_quest_date = today
    db.session.commit()

def check_daily_quest_completion(user_id):
    """Check if all daily quests for today are completed"""
    today = date.today()
    daily_quests = Quest.query.filter(
        Quest.user_id == user_id,
        Quest.created_at >= today,
        Quest.tags.like('%"daily"%')
    ).all()
    
    if not daily_quests:
        return False
    
    all_completed = all(quest.completed for quest in daily_quests)
    if all_completed:
        assignment = DailyQuestAssignment.query.filter_by(
            user_id=user_id,
            assigned_date=today
        ).first()
        if assignment:
            assignment.completed = True
            db.session.commit()
    
    return all_completed

def initialize_quest_templates():
    """Initialize default quest templates"""
    for category, quests in DAILY_QUEST_TEMPLATES.items():
        for quest_data in quests:
            existing = DailyQuestTemplate.query.filter_by(
                name=quest_data['name'],
                category=category
            ).first()
            
            if not existing:
                quest_template = DailyQuestTemplate(
                    name=quest_data['name'],
                    description=f"Complete {quest_data['target']} {quest_data['unit']} of {quest_data['name']}",
                    category=category,
                    base_reward=quest_data['base_reward'],
                    reward=quest_data['base_reward'],
                    duration=quest_data['duration'],
                    target=quest_data['target'],
                    unit=quest_data['unit'],
                    difficulty='easy'
                )
                db.session.add(quest_template)
    
    try:
        db.session.commit()
        print("Quest templates initialized successfully!")
    except Exception as e:
        db.session.rollback()
        print(f"Error initializing quest templates: {e}")

def init_db(app):
    """Initialize database with default data"""
    with app.app_context():
        db.create_all()
        initialize_quest_templates()
        
        if not User.query.first():
            default_user = User(
                username="demo",
                password_hash=generate_password_hash("demo123")
            )
            db.session.add(default_user)
            db.session.commit()
            print("Default user created: demo/demo123")