# ==================== app/routes.py ====================
from flask import render_template, request, redirect, url_for, flash, session, jsonify
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime, date
import json

from app import db
from app.models import User, Quest, DailyQuestAssignment
from app.utils import generate_daily_quests

def register_routes(app):
    
    @app.route('/')
    def index():
        if 'user_id' not in session:
            return redirect(url_for('login'))
        return redirect(url_for('dashboard'))

    @app.route('/register', methods=['GET', 'POST'])
    def register():
        if request.method == 'POST':
            username = request.form['username']
            password = request.form['password']
            
            if User.query.filter_by(username=username).first():
                flash('Username already exists')
                return redirect(url_for('register'))
                
            user = User(
                username=username,
                password_hash=generate_password_hash(password)
            )
            db.session.add(user)
            db.session.commit()
            flash('Registration successful!')
            return redirect(url_for('login'))
        return render_template('register.html')

    @app.route('/login', methods=['GET', 'POST'])
    def login():
        if request.method == 'POST':
            username = request.form.get('username')
            password = request.form.get('password')
            
            user = User.query.filter_by(username=username).first()
            if user and check_password_hash(user.password_hash, password):
                session['user_id'] = user.id
                flash('Logged in successfully!')
                return redirect(url_for('dashboard'))
            flash('Invalid username or password')
        return render_template('login.html')

    @app.route('/logout')
    def logout():
        session.pop('user_id', None)
        flash('Logged out successfully!')
        return redirect(url_for('login'))

    @app.route('/dashboard')
    def dashboard():
        if 'user_id' not in session:
            return redirect(url_for('login'))
        
        user = User.query.get_or_404(session['user_id'])

        active_quests = Quest.query.filter(
            Quest.user_id == user.id,
            Quest.completed == False,
            ~Quest.tags.like('%"daily"%')
        ).all()
        
        completed_quests = Quest.query.filter_by(
            user_id=user.id,
            completed=True
        ).all()
        
        return render_template('dashboard.html',
                             user=user,
                             completed_quests=completed_quests,
                             stats={
                                 'strength': user.strength,
                                 'agility': user.agility,
                                 'intelligence': user.intelligence,
                                 'stamina': user.stamina,
                                 'vitality': user.vitality,
                                 'perception': user.perception,
                                 'total_xp': user.xp,
                                 'xp_this_week': user.xp_this_week,
                                 'streak': user.streak,
                                 'achievements': user.get_achievements(),
                                 'active_quests': len(active_quests),
                                 'completed_quests': len(completed_quests)
                             })

    @app.route('/status')
    def status():
        if 'user_id' not in session:
            return redirect(url_for('login'))
        
        user = User.query.get_or_404(session['user_id'])
        return render_template('status.html', user=user,
                               stats={
                                 'level': user.level,
                                 'xp': user.xp,
                                 'strength': user.strength,
                                 'agility': user.agility,
                                 'intelligence': user.intelligence,
                                 'stamina': user.stamina,
                                 'vitality': user.vitality,
                                 'perception': user.perception,
                                 'total_xp': user.xp,
                                 'xp_this_week': user.xp_this_week,
                                 'streak': user.streak,
                                 'achievements': user.get_achievements(),
                                 'job': user.job,
                                 'title': user.title,
                                 'points': user.points,
                                 'coins': user.coins,
                                 'fatigue': user.fatigue,
                                 'xp_to_next_level': user.xp_to_next_level(),
                             })

    @app.route('/skills')
    def skills():
        if 'user_id' not in session:
            return redirect(url_for('login'))
        
        user = User.query.get_or_404(session['user_id'])
        return render_template('skills.html', user=user,
                               stats={
                                 'strength': user.strength,
                                 'agility': user.agility,
                                 'intelligence': user.intelligence,
                                 'stamina': user.stamina,
                                 'vitality': user.vitality,
                                 'perception': user.perception,
                                 'total_xp': user.xp,
                                 'xp_this_week': user.xp_this_week,
                                 'streak': user.streak,
                                 'achievements': user.get_achievements(),
                             })

    @app.route('/add_quest', methods=['GET', 'POST'])
    def add_quest():
        if 'user_id' not in session:
            return redirect(url_for('login'))
       
        user = User.query.get_or_404(session['user_id'])
       
        if request.method == 'POST':
            tags_string = request.form.get('tags[]', '')
            tags = [tag.strip() for tag in tags_string.split(',') if tag.strip()]
            
            duration = int(request.form.get('duration', 30))
            due_date_str = request.form.get('due_date')
            due_date = None
            if due_date_str:
                try:
                    due_date = datetime.strptime(due_date_str, '%Y-%m-%dT%H:%M')
                except ValueError:
                    flash('Invalid due date format')
                    return redirect(url_for('add_quest'))
            
            new_quest = Quest(
                name=request.form['name'],
                description=request.form['description'],
                duration=duration,
                difficulty=request.form.get('difficulty', 'Medium'),
                reward=int(request.form['reward']),
                priority=int(request.form.get('priority', 1)),
                due_date=due_date,
                user_id=session['user_id']
            )
            
            new_quest.set_tags(tags)
            
            db.session.add(new_quest)
            db.session.commit()
            
            flash('Quest added successfully!')
            return redirect(url_for('dashboard'))
       
        return render_template('add_quest.html', user=user)

    @app.route('/quests')
    def quests():
        if 'user_id' not in session:
            return redirect(url_for('login'))
        
        user = User.query.get_or_404(session['user_id'])
        generate_daily_quests(user.id)
        
        today = date.today()
        daily_quests = Quest.query.filter(
            Quest.user_id == user.id,
            Quest.created_at >= today,
            Quest.tags.like('%"daily"%'),
        ).all()
        
        active_quests = Quest.query.filter(
            Quest.user_id == user.id,
            Quest.completed == False,
            ~Quest.tags.like('%"daily"%')
        ).all()
        
        daily_assignment = DailyQuestAssignment.query.filter_by(
            user_id=user.id,
            assigned_date=today
        ).first()
        
        daily_category = daily_assignment.category if daily_assignment else None
        
        return render_template('quests.html', 
                             user=user,
                             daily_quests=daily_quests,
                             active_quests=active_quests,
                             daily_category=daily_category)

    @app.route('/edit_quest/<int:quest_id>', methods=['GET', 'POST'])
    def edit_quest(quest_id):
        if 'user_id' not in session:
            return redirect(url_for('login'))
        
        quest = Quest.query.get_or_404(quest_id)
        if quest.user_id != session['user_id']:
            flash('Unauthorized action')
            return redirect(url_for('dashboard'))
        
        if request.method == 'POST':
            quest.name = request.form['name']
            quest.description = request.form['description']
            quest.set_tags(request.form.getlist('tags[]'))
            quest.duration = int(request.form['duration'])
            quest.difficulty = request.form['difficulty']
            quest.reward = int(request.form['reward'])
            quest.priority = int(request.form.get('priority', 1))
            
            due_date_str = request.form.get('due_date')
            if due_date_str:
                try:
                    quest.due_date = datetime.strptime(due_date_str, '%Y-%m-%dT%H:%M')
                except ValueError:
                    flash('Invalid due date format')
                    return redirect(url_for('edit_quest', quest_id=quest_id))
            else:
                quest.due_date = None
            
            db.session.commit()
            flash('Quest updated successfully!')
            return redirect(url_for('dashboard'))
        
        return render_template('edit_quest.html', quest=quest)

    @app.route('/delete_quest/<int:quest_id>', methods=['POST'])
    def delete_quest(quest_id):
        if 'user_id' not in session:
            return redirect(url_for('login'))
        
        quest = Quest.query.get_or_404(quest_id)
        if quest.user_id != session['user_id']:
            flash('Unauthorized action')
            return redirect(url_for('dashboard'))
        
        db.session.delete(quest)
        db.session.commit()
        flash('Quest deleted successfully!')
        return redirect(url_for('dashboard'))

    @app.route('/complete_quest/<int:quest_id>', methods=['GET', 'POST'])
    def complete_quest(quest_id):
        if 'user_id' not in session:
            return redirect(url_for('login'))
        
        quest = Quest.query.get_or_404(quest_id)
        user_id = session['user_id']
        
        if quest.user_id != user_id:
            flash('Unauthorized action')
            return redirect(url_for('dashboard'))
        
        if not quest.completed:
            quest.completed = True
            quest.completion_date = datetime.utcnow()
            user = User.query.get(user_id)
            
            total_reward = quest.reward
            level_up_message = user.update_xp_and_level(total_reward)
            
            if user.xp_this_week is None:
                user.xp_this_week = 0
            user.xp_this_week += total_reward
            user.update_streak()
            
            new_achievements = user.check_and_award_achievements()
            
            today = date.today()
            daily_quests = Quest.query.filter(
                Quest.user_id == user_id,
                Quest.created_at >= today,
                Quest.tags.like('%"daily"%')
            ).all()
            
            all_daily_completed = all(dq.completed for dq in daily_quests)
            
            if daily_quests and all_daily_completed:
                assignment = DailyQuestAssignment.query.filter_by(
                    user_id=user_id,
                    assigned_date=today
                ).first()
                
                if assignment and not assignment.completed:
                    assignment.completed = True

            db.session.commit()

            flash(f'Quest completed! You earned {total_reward}xp!')
            if level_up_message:
                flash(level_up_message, 'success')
            for achievement in new_achievements:
                flash(f'New Achievement Unlocked: {achievement}', 'success')

        return redirect(url_for('dashboard'))

    @app.route('/reward')
    def reward():
        if 'user_id' not in session:
            return redirect(url_for('login'))
        
        user = User.query.get_or_404(session['user_id'])
        
        today = date.today()
        completed_quests = Quest.query.filter(
            Quest.user_id == user.id,
            Quest.completed == True,
            Quest.completion_date >= datetime.combine(today, datetime.min.time())
        ).order_by(Quest.completion_date.desc()).limit(5).all()
        
        reward_options = {
            'stat_points': {'name': 'Stat Points (+3)', 'icon': '📊'},
            'strength': {'name': 'Strength (+2)', 'icon': '💪'},
            'intelligence': {'name': 'Intelligence (+2)', 'icon': '🧠'},
            'agility': {'name': 'Agility (+2)', 'icon': '⚡'},
        }
        
        return render_template('rewards.html', 
                             reward_options=reward_options,
                             completed_quests=completed_quests,
                             user=user)

    @app.route('/claim_reward', methods=['POST'])
    def claim_reward():
        if 'user_id' not in session:
            flash('Please login first', 'error')
            return redirect(url_for('login'))
        
        reward_type = request.form.get('reward_type')
        
        if not reward_type:
            flash('Invalid reward selection', 'error')
            return redirect(url_for('dashboard'))
        
        try:
            user = User.query.get(session['user_id'])
            
            if not user:
                flash('User not found', 'error')
                return redirect(url_for('login'))
            
            reward_effects = {
                'stat_points': {
                    'name': 'Stat Points',
                    'message': 'You gained +3 stat points!',
                    'action': lambda u: setattr(u, 'points', u.points + 3)
                },
                'strength': {
                    'name': 'Strength Boost',
                    'message': 'Your strength increased by +2!',
                    'action': lambda u: setattr(u, 'strength', u.strength + 2)
                },
                'intelligence': {
                    'name': 'Intelligence Boost',
                    'message': 'Your intelligence increased by +2!',
                    'action': lambda u: setattr(u, 'intelligence', u.intelligence + 2)
                },
                'agility': {
                    'name': 'Agility Boost',
                    'message': 'Your agility increased by +2!',
                    'action': lambda u: setattr(u, 'agility', u.agility + 2)
                },
                'vitality': {
                    'name': 'Vitality Boost',
                    'message': 'Your vitality increased by +2!',
                    'action': lambda u: setattr(u, 'vitality', u.vitality + 2)
                },
                'stamina': {
                    'name': 'Stamina Boost',
                    'message': 'Your stamina increased by +2!',
                    'action': lambda u: setattr(u, 'stamina', u.stamina + 2)
                },
                'perception': {
                    'name': 'Perception Boost',
                    'message': 'Your perception increased by +2!',
                    'action': lambda u: setattr(u, 'perception', u.perception + 2)
                }
            }
            
            if reward_type not in reward_effects:
                flash('Invalid reward type', 'error')
                return redirect(url_for('dashboard'))
            
            reward = reward_effects[reward_type]
            reward['action'](user)
            user.last_reward_claimed = datetime.utcnow()
            db.session.commit()
            flash(f'🎁 {reward["message"]}', 'success')
            
        except Exception as e:
            db.session.rollback()
            flash('An error occurred while claiming your reward', 'error')
            print(f"Error claiming reward: {e}")
        
        return redirect(url_for('dashboard'))

    @app.route('/add_stat', methods=['POST'])
    def add_stat():
        if 'user_id' not in session:
            return redirect(url_for('login'))
        
        user = User.query.get_or_404(session['user_id'])
        stat_type = request.form.get('stat_type')
        
        if user.points <= 0:
            flash('No available stat points!', 'error')
            return redirect(url_for('status'))
        
        valid_stats = ['strength', 'intelligence', 'agility', 'stamina', 'vitality', 'perception']
        
        if stat_type not in valid_stats:
            flash('Invalid stat type!', 'error')
            return redirect(url_for('status'))
        
        current_value = getattr(user, stat_type)
        setattr(user, stat_type, current_value + 1)
        user.points -= 1
        db.session.commit()
        
        return redirect(url_for('status'))

    @app.route('/suggest_description', methods=['POST'])
    def suggest_description():
        try:
            quest_title = request.json['questTitle']
            suggested_description = ""  # Placeholder
            return jsonify({'suggestedDescription': suggested_description})
        except Exception as e:
            return jsonify({'error': str(e)}), 500

