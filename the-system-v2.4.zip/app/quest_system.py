# ==================== app/quest_system.py ====================
"""
Adaptive Quest System
Handles dynamic quest generation based on user level and performance
"""
from datetime import datetime, timedelta
import math

# Base templates - scaled based on user level and performance
DAILY_QUEST_TEMPLATES = {
    'strength': [
        {'name': 'Push-ups', 'target': 5, 'unit': 'reps', 'base_reward': 5, 'duration': 30, 'scaling_factor': 2},
        {'name': 'Sit-ups', 'target': 5, 'unit': 'reps', 'base_reward': 5, 'duration': 30, 'scaling_factor': 2},
        {'name': 'Squats', 'target': 5, 'unit': 'reps', 'base_reward': 5, 'duration': 30, 'scaling_factor': 2},
        {'name': 'Running', 'target': 1, 'unit': 'km', 'base_reward': 10, 'duration': 60, 'scaling_factor': 0.5}
    ],
    'intelligence': [
        {'name': 'Read a Book', 'target': 3, 'unit': 'mins', 'base_reward': 8, 'duration': 45, 'scaling_factor': 5},
        {'name': 'Journal', 'target': 4, 'unit': 'mins', 'base_reward': 3, 'duration': 30, 'scaling_factor': 3},
        {'name': 'Study a Topic', 'target': 6, 'unit': 'mins', 'base_reward': 6, 'duration': 60, 'scaling_factor': 5}
    ],
    'agility': [
        {'name': 'Jump Rope', 'target': 5, 'unit': 'mins', 'base_reward': 4, 'duration': 15, 'scaling_factor': 2},
        {'name': 'Stretching', 'target': 5, 'unit': 'mins', 'base_reward': 3, 'duration': 30, 'scaling_factor': 2},
        {'name': 'Sprinting', 'target': 5, 'unit': 'mins', 'base_reward': 5, 'duration': 20, 'scaling_factor': 2}
    ]
}

def get_user_performance_stats(user, category):
    """Analyze user's past performance for a specific category."""
    from app.models import Quest, DailyQuestAssignment
    
    thirty_days_ago = datetime.utcnow() - timedelta(days=30)
    
    category_quests = Quest.query.filter(
        Quest.user_id == user.id,
        Quest.created_at >= thirty_days_ago,
        Quest.tags.like(f'%{category}%')
    ).all()
    
    daily_quests = DailyQuestAssignment.query.filter(
        DailyQuestAssignment.user_id == user.id,
        DailyQuestAssignment.category == category,
        DailyQuestAssignment.assigned_date >= thirty_days_ago.date()
    ).all()
    
    total_quests = len(category_quests) + len(daily_quests)
    completed_quests = sum(1 for q in category_quests if q.completed) + sum(1 for q in daily_quests if q.completed)
    
    completion_rate = completed_quests / total_quests if total_quests > 0 else 0.5
    attribute_level = getattr(user, category, 10)
    
    return {
        'completion_rate': completion_rate,
        'attribute_level': attribute_level,
        'total_attempts': total_quests
    }

def calculate_adaptive_quest(template, user, category):
    """Calculate quest parameters based on user level, stats, and performance."""
    stats = get_user_performance_stats(user, category)
    
    level_multiplier = 1 + (user.level - 1) * 0.15
    attribute_multiplier = 1 + (stats['attribute_level'] - 10) * 0.05
    
    completion_rate = stats['completion_rate']
    if completion_rate > 0.8:
        performance_multiplier = 1.2
    elif completion_rate < 0.4:
        performance_multiplier = 0.8
    else:
        performance_multiplier = 1.0
    
    base_target = template['target']
    scaling_factor = template.get('scaling_factor', 1)
    
    total_multiplier = level_multiplier * attribute_multiplier * performance_multiplier
    new_target = math.ceil(base_target + (base_target * scaling_factor * (total_multiplier - 1)))
    
    duration_increase = (new_target / base_target - 1) * 0.5
    new_duration = math.ceil(template['duration'] * (1 + duration_increase))
    
    difficulty_factor = new_target / base_target
    new_reward = math.ceil(template['base_reward'] * difficulty_factor * level_multiplier)
    
    if total_multiplier < 1.2:
        difficulty = 'Easy'
    elif total_multiplier < 1.8:
        difficulty = 'Medium'
    elif total_multiplier < 2.5:
        difficulty = 'Hard'
    else:
        difficulty = 'Expert'
    
    return {
        'name': template['name'],
        'target': new_target,
        'unit': template['unit'],
        'reward': new_reward,
        'duration': new_duration,
        'difficulty': difficulty,
        'category': category,
        'scaling_info': {
            'level_mult': round(level_multiplier, 2),
            'attr_mult': round(attribute_multiplier, 2),
            'perf_mult': round(performance_multiplier, 2),
            'total_mult': round(total_multiplier, 2)
        }
    }

def generate_daily_quests_for_user(user, selected_category=None):
    """
    Generate adaptive daily quests for a user from ONE category only.
    
    Args:
        user: User object
        selected_category: Specific category to use, or None to randomly select
    
    Returns:
        List of quest data dictionaries for the selected category
    """
    import random
    
    # If no category specified, randomly select one
    if selected_category is None:
        selected_category = random.choice(list(DAILY_QUEST_TEMPLATES.keys()))
    
    daily_quests = []
    templates = DAILY_QUEST_TEMPLATES[selected_category]
    
    # Generate quests for ALL templates in the selected category
    for template in templates:
        quest_data = calculate_adaptive_quest(template, user, selected_category)
        daily_quests.append(quest_data)
    
    return daily_quests, selected_category