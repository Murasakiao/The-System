# ==================== app/models.py ====================
from app import db
from datetime import datetime
from werkzeug.security import generate_password_hash, check_password_hash
import json

LEVEL_THRESHOLDS = {
    1: 0, 2: 99, 3: 250, 4: 500, 5: 1000,
    6: 2000, 7: 3500, 8: 5500, 9: 8000, 10: 11000,
    11: 14500, 12: 18500, 13: 23000, 14: 28000, 15: 33500,
    16: 39500, 17: 46000, 18: 53000, 19: 60500, 20: 68500,
    21: 77000, 22: 86000, 23: 95500, 24: 105500, 25: 116000
}

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    password_hash = db.Column(db.String(120), nullable=False)
    xp = db.Column(db.Integer, default=0)
    level = db.Column(db.Integer, default=1)
    strength = db.Column(db.Integer, default=10)
    agility = db.Column(db.Integer, default=10)
    stamina = db.Column(db.Integer, default=10)
    intelligence = db.Column(db.Integer, default=10)
    vitality = db.Column(db.Integer, default=10)
    perception = db.Column(db.Integer, default=10)
    job = db.Column(db.String(50), default='Novice')
    title = db.Column(db.String(50), default='Dragon Slayer')
    name = db.Column(db.String(100), default='Player')
    age = db.Column(db.Integer, default=18)
    sex = db.Column(db.String(10), default='Unknown')
    coins = db.Column(db.Integer, default=0)
    points = db.Column(db.Integer, default=5)
    fatigue = db.Column(db.Integer, default=100)
    streak = db.Column(db.Integer, default=0)
    last_completed_date = db.Column(db.DateTime, nullable=True)
    xp_this_week = db.Column(db.Integer, default=0)
    achievements = db.Column(db.Text, default="")
    last_daily_quest_date = db.Column(db.Date, nullable=True)
    last_reward_claimed = db.Column(db.DateTime, nullable=True)

    quests = db.relationship('Quest', backref='user', lazy=True)
    daily_quests = db.relationship('DailyQuestAssignment', backref='user', lazy=True)

    ACHIEVEMENTS = {
        'WEEK_WARRIOR': {'id': 'WEEK_WARRIOR', 'name': '100 XP This Week!', 
                        'condition': lambda user: user.xp_this_week >= 100},
        'STREAK_MASTER': {'id': 'STREAK_MASTER', 'name': '7-Day Streak Achieved!', 
                         'condition': lambda user: user.streak >= 7},
        'LEVEL_MASTER': {'id': 'LEVEL_MASTER', 'name': 'Level Master!', 
                        'condition': lambda user: user.xp >= 1000},
        'XP_PRODIGY': {'id': 'XP_PRODIGY', 'name': '500 XP in Total!', 
                      'condition': lambda user: user.xp >= 500},
        'WEEK_CHAMPION': {'id': 'WEEK_CHAMPION', 'name': '200 xp This Week!', 
                         'condition': lambda user: user.xp_this_week >= 200},
        'STREAK_LEGEND': {'id': 'STREAK_LEGEND', 'name': '14-Day Streak!', 
                         'condition': lambda user: user.streak >= 14},
        'MONTHLY_GRINDER': {'id': 'MONTHLY_GRINDER', 'name': '300 xp in Four Weeks!', 
                           'condition': lambda user: user.xp_this_week >= 300},
        'STREAK_MARATHONER': {'id': 'STREAK_MARATHONER', 'name': '30-Day Streak!', 
                             'condition': lambda user: user.streak >= 30},
        'HALFWAY_HERO': {'id': 'HALFWAY_HERO', 'name': 'Reach Halfway to 1000 xp!', 
                        'condition': lambda user: user.xp >= 500},
        'STREAK_STARTER': {'id': 'STREAK_STARTER', 'name': 'First 3-Day Streak!', 
                          'condition': lambda user: user.streak >= 3},
        'WEEK_CONTRIBUTOR': {'id': 'WEEK_CONTRIBUTOR', 'name': '50 xp This Week!', 
                            'condition': lambda user: user.xp_this_week >= 50},
        'LIFELONG_LEARNER': {'id': 'LIFELONG_LEARNER', 'name': '2000 Total xp!', 
                            'condition': lambda user: user.xp >= 2000}
    }

    def can_claim_reward(self):
        if not self.last_reward_claimed:
            return True
        time_since_claim = datetime.utcnow() - self.last_reward_claimed
        return time_since_claim.total_seconds() >= 86400

    def update_streak(self):
        today = datetime.utcnow().date()
        if self.last_completed_date is None:
            self.streak = 1
        else:
            last_completion = self.last_completed_date.date()
            days_difference = (today - last_completion).days
            if days_difference == 1:
                self.streak += 1
            elif days_difference > 1:
                self.streak = 1
        self.last_completed_date = datetime.utcnow()

    def add_achievement(self, achievement_id):
        if achievement_id not in self.ACHIEVEMENTS:
            return False
        current_achievements = self.get_achievements()
        if achievement_id not in current_achievements:
            current_achievements.append(achievement_id)
            self.achievements = ";".join(current_achievements)
            return True
        return False

    def get_achievements(self):
        return [ach.strip() for ach in self.achievements.split(";") if ach.strip()]

    def get_achievement_names(self):
        achievement_ids = self.get_achievements()
        return [self.ACHIEVEMENTS[aid]['name'] for aid in achievement_ids if aid in self.ACHIEVEMENTS]

    def check_and_award_achievements(self):
        new_achievements = []
        for achievement_id, achievement in self.ACHIEVEMENTS.items():
            if (achievement_id not in self.get_achievements() and 
                achievement['condition'](self)):
                if self.add_achievement(achievement_id):
                    new_achievements.append(achievement['name'])
        return new_achievements

    def calculate_level(self):
        current_level = 1
        for level, threshold in sorted(LEVEL_THRESHOLDS.items()):
            if self.xp >= threshold:
                current_level = level
            else:
                break
        return current_level

    def xp_to_next_level(self):
        current_level = self.level
        if current_level >= max(LEVEL_THRESHOLDS.keys()):
            return None
        next_level = current_level + 1
        xp_needed = LEVEL_THRESHOLDS[next_level] - self.xp
        return max(0, xp_needed)

    def level_progress_percentage(self):
        if self.level >= max(LEVEL_THRESHOLDS.keys()):
            return 100
        current_level_threshold = LEVEL_THRESHOLDS[self.level]
        next_level_threshold = LEVEL_THRESHOLDS[self.level + 1]
        xp_in_current_level = self.xp - current_level_threshold
        xp_needed_for_level = next_level_threshold - current_level_threshold
        percentage = (xp_in_current_level / xp_needed_for_level) * 100
        return min(100, max(0, percentage))

    def update_xp_and_level(self, xp_earned):
        old_level = self.level
        self.xp += xp_earned
        new_level = self.calculate_level()
        level_up_message = None
        if new_level > old_level:
            self.level = new_level
            level_up_message = f"Congratulations! You've reached level {new_level}!"
        return level_up_message

    def to_dict(self):
        return {
            'id': self.id,
            'username': self.username,
            'xp': self.xp,
            'level': self.level,
            'streak': self.streak,
            'xp_this_week': self.xp_this_week,
            'achievements': self.get_achievement_names()
        }


class DailyQuestTemplate(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    category = db.Column(db.String(50), nullable=False)
    reward = db.Column(db.Integer, default=30)
    name = db.Column(db.String(100), nullable=False)
    description = db.Column(db.Text, nullable=False)
    base_reward = db.Column(db.Integer, nullable=False)
    duration = db.Column(db.Integer, nullable=False)
    target = db.Column(db.Integer, nullable=True)
    unit = db.Column(db.String(20), nullable=True)
    difficulty = db.Column(db.String(20), default='Medium')


class DailyQuestAssignment(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    assigned_date = db.Column(db.Date, nullable=False)
    category = db.Column(db.String(50), nullable=False)
    completed = db.Column(db.Boolean, default=False)


class Quest(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text, nullable=True)
    target = db.Column(db.Integer, nullable=True)
    unit = db.Column(db.String(20), nullable=True)
    tags = db.Column(db.Text, default='[]')
    duration = db.Column(db.Integer, nullable=False, default=30)
    difficulty = db.Column(db.String(20), nullable=False, default='Medium')
    base_reward = db.Column(db.Integer, nullable=False, default=5)
    reward = db.Column(db.Integer)
    completed = db.Column(db.Boolean, default=False)
    completion_date = db.Column(db.DateTime, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    due_date = db.Column(db.DateTime, nullable=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    priority = db.Column(db.Integer, default=1)

    def set_tags(self, tags_list):
        if isinstance(tags_list, list):
            self.tags = json.dumps(tags_list)
        else:
            self.tags = '[]'

    def get_tags(self):
        try:
            return json.loads(self.tags)
        except (json.JSONDecodeError, TypeError):
            return []

    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'description': self.description or '',
            'tags': self.get_tags(),
            'duration': self.duration,
            'difficulty': self.difficulty,
            'reward': self.reward,
            'completed': self.completed,
            'completion_date': self.completion_date.strftime('%Y-%m-%d %H:%M:%S') if self.completion_date else None,
            'created_at': self.created_at.strftime('%Y-%m-%d %H:%M:%S'),
            'due_date': self.due_date.strftime('%Y-%m-%d %H:%M:%S') if self.due_date else None,
            'priority': self.priority
        }
