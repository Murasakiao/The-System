# ==================== system.py (UPDATED - Root directory) ====================
"""
Legacy system.py file for backward compatibility
All functionality has been moved to app/quest_system.py
"""

from app.models import LEVEL_THRESHOLDS
from app.quest_system import (
    DAILY_QUEST_TEMPLATES,
    get_user_performance_stats,
    calculate_adaptive_quest,
    generate_daily_quests_for_user
)

def get_user_level(user_xp):
    """Calculate user level based on XP"""
    level = 1
    for lvl, xp_threshold in sorted(LEVEL_THRESHOLDS.items()):
        if user_xp >= xp_threshold:
            level = lvl
        else:
            break
    return level