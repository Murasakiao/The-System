# Dictionary of quest templates
DAILY_QUEST_TEMPLATES = {
    'strength': [
        {
            'name': 'Push-ups',
            'target' : 5, # 5 + level * 2
            "unit" : "reps",
            'base_reward': 5,
            'duration': 30,
        },
        {
            'name': 'Sit-ups',
            'target' : 5,
            "unit" : "reps",
            'base_reward': 5,
            'duration': 30,
        },
        {
            'name': 'Squats',
            'target' : 5,
            "unit" : "reps",
            'base_reward': 5,
            'duration': 30,
        },
        {
            'name': 'Running',
            'target' : 1,
            "unit" : "km",
            'base_reward': 10,
            'duration': 60,
        }
    ],
    'intelligence': [
        {
            'name': 'Read a Book',
            'target' : 3,
            "unit" : "mins",
            'base_reward': 400,
            'duration': 45,
        },
        {
            'name': 'Journal',
            'target' : 4,
            "unit" : "mins",
            'base_reward': 3,
            'duration': 30,
        },
        {
            'name': 'Study a Topic',
            'target' : 6,
            "unit" : "mins",
            'base_reward': 6,
            'duration': 60,
        }
    ],
    'agility': [
        {
            'name': 'Jump Rope',
            'target' : 5,
            "unit" : "mins",
            'base_reward': 400,
            'duration': 15,
        },
        {
            'name': 'Stretching',
            'target' : 5,
            "unit" : "mins",
            'base_reward': 3,
            'duration': 30,
        },
        {
            'name': 'Sprinting',
            'target' : 5,
            "unit" : "mins",
            'base_reward': 5,
            'duration': 20,
        }
    ]
}